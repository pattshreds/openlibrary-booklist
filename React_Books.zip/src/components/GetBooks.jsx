import React, { useState } from "react";
import axios from 'axios';

const GetBooks = () => {

const [books, setBooks] = useState([]);

    const fetchData = () => {
        axios.get(`https://openlibrary.org/search.json?q=${document.getElementById('input').value}`)
            .then((res) => {
                setBooks(res.data.docs)
            })
            .catch((error) => {
                console.log(error);
            })
    };

    return(
        <>
            <h1 id='pageTitle'>Welcome to React Books</h1>
            <input type="text" id="input" />
            <button onClick={fetchData} id='searchBtn'>Search</button>
            <ol id='resultsList'>
                {books.slice(0, 10).map((book) => {
                    return(
                        <li key={book.key} className='resultsListLi'>
                            <h3 className='bookTitle'>{book.title}</h3>
                            <p id='author_name'>Written by {book.author_name}
                            </p>
                            <p id='publish_year'>Published {book.first_publish_year}
                            </p>
                            <hr className='bookDivider' />
                        </li>
                        
                    )
                })}
            </ol>
        </>
    )
}

export default GetBooks;
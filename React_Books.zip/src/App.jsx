import './styles/style.css'
import GetBooks from './components/GetBooks';

function App() {

  return (
    <>
      <GetBooks />
    </>
  )
}

export default App
